# Octoxlabs Integration Case Study

## Proje Mimarisi


#### Özellikler:
- **OAuth2 Authentication**: Client credentials flow
- **Rate Limiting**: X-RateLimit-Remaining ve X-RateLimit-RetryAfter header'ları
- **Custom Pagination**: Verilen örnek data formatında(meta, errors, resources)
- **Test Modları**: Query parameter ile fail case simülasyonu

#### Endpoints:
```
GET  /health/                              # Health check
POST /oauth2/token/                        # Token alma
GET  /devices/host-groups/                 # Host group listesi (paginated)
GET  /devices/devices/                     # Device ID listesi (paginated)
POST /devices/entities/                    # Device detayları (batch)
POST /devices/entities/online-state/       # Device state'leri (batch)
```


#### Client Credentials setup_oauth.py'ın içinde tekrar admin panelden demo için Oauth uygulama yaratmaktansa gösterirken daha kolay olur diye düşündüm

OAuth2 Application'ı otomatik oluşturmak için

```bash
python manage.py setup_oauth
```


### 2. Async Client (Python asyncio + aiohttp)

API'den veri çeken ve Elasticsearch'e kaydeden async script.

#### Akış:

```
1. Token Al (OAuth2)
   ↓
2. Host Groups Çek (pagination ile tümü)
   ↓
3. Device ID'leri Çek (pagination ile tümü)
   ↓
4. Device Detayları Çek (batch: 10'ar 10'ar, concurrent)
   ↓
5. Device State'leri Çek (batch: 10'ar 10'ar, concurrent)
   ↓
6. Group Bilgilerini Ekle (enrichment)
   ↓
7. Elasticsearch'e Kaydet (batch write)
```

#### Rate Limit Yönetimi:

```python
# Her response'dan rate limit bilgisi al
remaining = int(response.headers.get('X-RateLimit-Remaining', 100))
retry_after = int(response.headers.get('X-RateLimit-RetryAfter', 60))

# Remaining düşükse bekle
if remaining < 10:
    await asyncio.sleep(retry_after)
```


#### Exponential Backoff:

```python
# Retry mekanizması: 2s, 4s, 8s
for attempt in range(3):
    try:
        response = await fetch()
        break
    except (500, 502, 503, 504):
        wait = 2 ** attempt  # 1, 2, 4, 8
        await asyncio.sleep(wait)
```

**Retry yapılan durumlar:**
- 429 (Rate Limit)
- 500, 502, 503, 504 (Server errors)

#### ID Deduplication:

```python
# Pagination'dan gelen ID'leri dedupe et
device_ids = list(set(all_device_ids))
```

#### Eksik ID Retry:

```python
# API'den gelen device sayısı ile istenen sayı eşleşmezse
if len(fetched_devices) < len(requested_ids):
    missing_ids = set(requested_ids) - set(fetched_device_ids)
    # Eksik ID'leri tekrar dene
```

### 3. Test Senaryoları

`client/test_scenarios.py` ile fail case'leri test edebilirsin:

```bash
cd client
python test_scenarios.py
```

**Test edilen senaryolar:**
1. Rate limit hit (Remaining=0)
2. Server error + exponential backoff
3. Eksik device ID'ler
4. Rate limit bekleme mekanizması
5. Concurrent requests ile rate limit paylaşımı

**Test modları** (API middleware'de):
```
?test_mode=rate_limit_hit   # Remaining=0 döndür
?test_mode=server_error      # 500 error döndür
?test_mode=slow_response     # 2 saniye beklet
```

## Elasticsearch

### Index'ler:

**octoxlabs-data**: Device verileri
```json
{
  "device_id": "device_001",
  "hostname": "DESKTOP-PROD-001",
  "platform_name": "Windows",
  "state": "online",
  "groups": ["Production Servers", "Development Team"]
}
```

**octoxlabs-log**: Script logları
```json
{
  "timestamp": "2024-01-13T10:30:00Z",
  "level": "INFO",
  "message": "25 device cekildi"
}
```

## Proje Yapısı

```
.
├── api/
│   ├── models.py                      # HostGroup, Device, DeviceState
│   ├── serializers.py                 # DRF serializers
│   ├── views.py                       # API endpoints
│   ├── paginators.py                  # Custom pagination (CrowdStrike format)
│   ├── middleware.py                  # Rate limit middleware + test modes
│   ├── management/commands/
│   │   └── setup_oauth.py            # OAuth2 Application oluşturur
│   └── fixtures/test_data.json       # 5 groups, 25 devices, 25 states
├── client/
│   ├── async_client.py               # Ana script (async + rate limit + retry)
│   ├── test_scenarios.py             # Fail case testleri
│   └── .env                          # Client credentials
├── mock_api/
│   ├── settings.py                   # Django settings
│   └── urls.py                       # URL routing
├── docker-compose.yml                # 3 servis: elasticsearch, api, client
├── Dockerfile                        # API Dockerfile
└── README.md                         # Bu dosya
```

