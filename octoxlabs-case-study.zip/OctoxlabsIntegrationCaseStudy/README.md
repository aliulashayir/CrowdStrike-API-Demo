
# Octoxlabs Integration Case

Bir güvenlik ekibinde çalıştığını düşün. Görevin, bir API’den büyük hacimli cihaz verilerini çekmek ve işlemek. Ancak bu API belirli **rate limit** kısıtlamalarına sahip ve on binlerce kaydı işlerken hem **hızlı** hem de **bellek dostu** bir çözüm üretmen gerekiyor.  

Bu case çalışmasında adaydan, **Python script'i** yazarak API’den veri çekerken **rate limit mekanizmasını doğru yönetmesi**, **eş zamanlı** istekler ile performansı artırması ve aynı zamanda **memory-efficient** bir yaklaşım kullanması beklenmektedir.

Oluşturulan veri **Elasticsearch’te** `octoxlabs-data` index’ine kaydedilmeli ve adaydan, **Elasticsearch** ile **Python script’ini** **dockerize** edip **docker compose** ile container’ları çalıştırıp yönetebilmesi beklenmektedir.

Logların uygun log seviyeleriyle birlikte **Elasticsearch’te** `octoxlabs-log` index’ine kaydedilmesi beklenmektedir.

> **Not:** Tüm örnek response dosyalarındaki veriler **randomize edilmiştir**. ID’ler birbirleriyle birebir eşleşmeyebilir. Bu nedenle datayı kendi test senaryoların için **kendince refactor etmen** beklenmektedir.  

---

## Authentication (`/oauth2/token`- **POST**)

Scriptin ilk adımı, **client_id** ve **client_secret** bilgilerini kullanarak **authentication token** almaktır. Bunun için `/oauth2/token` endpoint’ine istek atılır. Dönen response içerisindeki `access_token` değeri, sonraki tüm API çağrılarında **Authorization header**’ında Bearer Token olarak kullanılmalıdır.

---

## Rate-Limit Mekanizması

API, başlangıçta **5000 adet request hakkı** tanımlar. Her yapılan istekten sonra bu haklar azalır ve yanıtın HTTP header’larında aşağıdaki alanlar döner:

- **`X-RateLimit-Remaining`** → Kalan istek hakkı sayısını gösterir  
- **`X-RateLimit-RetryAfter`** → İstek hakkının yenileneceği zamanı gösterir (timestamp formatında)  

**Örnek header’lar:**

```
X-RateLimit-Remaining: 4987
X-RateLimit-RetryAfter: 1736131200
```

Buradaki `1736131200` değeri bir **Unix epoch timestamp**’tir.  
Örn: `1736131200 → 2025-01-06 12:00:00 UTC`

### Kurallar & Beklentiler

- Script her istekten sonra `X-RateLimit-Remaining` değerini kontrol etmeli.  
- Eğer bu değer `0` veya çok küçükse, yeni istek göndermeden önce `X-RateLimit-RetryAfter` değerine kadar beklemelidir.  
- Bekleme mekanizması **exponential backoff** ile desteklenebilir (örn. 1s, 2s, 4s …).  
- Eş zamanlı istekler kullanıldığında rate-limit paylaşımı **merkezi** bir şekilde yönetilmelidir (global counter + lock veya semaphore benzeri bir yapı).  

---

## Host Group bilgilerini çekme (`/devices/host-groups` — **GET**)

Bu adımda API’den **host group** bilgileri alınacaktır. Endpoint **pagination** destekler ve `limit` ile `offset` parametreleri kullanılır.  

Örnek yanıt yapıları: `group_info_1.json`, `group_info_2.json`  

> **Not:** Response dosyalarındaki veriler randomize edilmiştir. ID’ler eşleşmeyebilir; test senaryoların için kendince refactor etmelisin.  

### Kurallar & Beklentiler

- Offset tabanlı sayfalama: `?limit=<L>&offset=<O>`  
- Maksimum offset değeri **500**’dür.  
- Tüm sayfalar, `total` değeri kapsanıncaya kadar çekilmelidir.  
- Rate-limit durumlarında exponential backoff + retry uygulanmalıdır.  
- **Memory-efficient**: Yanıtlar RAM’de biriktirilmeden işlenmelidir.  
- **Concurrency**: Eş zamanlı olarak birden fazla page çekilebilir.  

---

## Device’ları listeleme (`/devices/devices` — **GET**)

Bu adımda **cihaz listesi** alınır. Endpoint yine `limit` ve `offset` parametreleriyle çalışır.  

Örnek yanıtlar: `device_scroll_1.json`, `device_scroll_2.json`, `device_scroll_3.json`  

> **Not:** Response dosyalarındaki veriler randomize edilmiştir. ID’ler eşleşmeyebilir; test senaryoların için kendince refactor etmelisin.  

### Kurallar & Beklentiler

- Pagination ile tüm kayıtlar çekilmeli (`meta.pagination.total`).  
- Rate-limit durumlarında exponential backoff + retry.  
- Concurrency: Eş zamanlı olarak birden fazla offset çekilebilir.  
- **Memory-efficient**: Her sayfa işlenmeli, tüm liste RAM’de biriktirilmemelidir.  
- `device_id` değerleri çıkarılmalı, **dedupe edilerek** tutulmalıdır.  
- Yinelenen veya eksik alanlar loglanmalı.  
- (Opsiyonel) Resume/checkpoint desteği.  

---

## Device detaylarını toplama (`/devices/entities` — **POST**)

Önceki adımdan alınan `device_id` değerleri bu endpoint’e **JSON body** içinde `ids` parametresiyle array şeklinde gönderilir. Tek istekte birden fazla cihaz detayı döner.  

Örnek yanıtlar: `device_detail_1.json`, `device_detail_2.json`  

> **Not:** Response dosyalarındaki veriler randomize edilmiştir. ID’ler eşleşmeyebilir; test senaryoların için kendince refactor etmelisin.  

### Kurallar & Beklentiler

- **Batching**: `ids` listesi mantıklı parçalara bölünmeli (örn. max 10 id).  
- **Concurrency + Rate Limit**: Eş zamanlı istekler yapılabilir ancak rate-limit yönetimine uyulmalı.  
- **Eksik/kayıp ID’ler** loglanmalı.  
- Başarısız ID’ler küçük batch’lerle yeniden denenebilir.  
- **Deterministik kayıt**: Aynı device_id birden fazla kez gelirse en son veya en zengin kayıt kullanılmalı.  

---

## Device online status bilgilerini toplama (`/devices/entities/online-state` — **POST**)

Bu adımda cihazların **online/offline** durumları alınır. Yöntem, device detaylarıyla aynıdır.  

Örnek yanıtlar: `status_1.json`, `status_2.json`  

> **Not:** Response dosyalarındaki veriler randomize edilmiştir. ID’ler eşleşmeyebilir; test senaryoların için kendince refactor etmelisin.  

### Kurallar & Beklentiler

- **Batching**: `ids` listesi mantıklı şekilde parçalara bölünmeli (örn. max 10 id).  
- Concurrency + Rate Limit kuralları geçerlidir.  
- Eksik yanıtlanan ID’ler loglanmalı, gerekirse retry yapılmalı.  

---

## Cihazlara group bilgilerini iliştirme (Enrichment)

Her cihaz detayında bulunan `groups` alanındaki **group id**’ler, ilk adımda alınan **host group** id’leriyle eşleşir.  
Her cihaz objesine `group_info` adında bir array eklenmeli ve ilgili grupların tüm detayları buraya yazılmalıdır.  

> **Not:** Response dosyalarındaki veriler randomize edilmiştir. ID’ler eşleşmeyebilir; test senaryoların için kendince refactor etmelisin.  

### Kurallar & Beklentiler

- `group_info` alfabetik sıralanmalı, tekrarlı id’ler dedupe edilmelidir.  
- Eşleşmeyen id’ler loglanmalı.  
- Büyük datasetlerde memory kullanımı için host group’lar **dict** veya benzeri hafif yapı ile işlenebilir.  

---

## Genel Kurallar – Özet

- **Tek ve ortak Rate-Limit havuzu**: Tüm endpoint’ler aynı limit’i paylaşır.  
- **Rate-Limit uygulaması**: Remaining = 0 ise RetryAfter’a kadar bekle.  
- **Concurrency**: Eş zamanlı istekler yapılabilir ancak Rate-Limit'e dikkat edilmesi gerekir.
- **Memory-efficient**:  
  - Büyük yanıtlar stream edilerek işlenmeli, RAM’de tutulmamalı.  
  - ID listeleri dedupe edilmeli, gerekirse checkpoint desteği olmalı.  
- **Hata dayanıklılığı**:  
  - Geçici hatalarda retry + backoff, kalıcı hatalarda anlamlı log.  
  - Eksik ID’ler küçük batch’lerle yeniden denenmeli.
- **Verinin kaydedilmesi**:
  - Oluşturulan veri Elasticsearch'te `octoxlabs-data` index’ine kaydedilmeli.
- **Log Yönetimi**:
  - Script logları, uygun log seviyeleri (DEBUG, INFO, WARNING, ERROR, CRITICAL) ile birlikte Elasticsearch’te `octoxlabs-log` index’ine kaydedilmeli.
